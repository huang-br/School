To run this program simply type make. This will defualt to using the dictionary.txt provided, and some
text file called input.txt

To run this program with a different input file type in command line "python bloomfilter.py dictionary.txt [yourinput.txt]" where
yourinput.txt is the input file.

After running this command it will then create output3.txt and output5.txt

