To run the program simply just run the command 'python TOTP.py' This should print the shared key, then print the generated key. The program seems to work correctly
but it does not match the result on google authenticator.
