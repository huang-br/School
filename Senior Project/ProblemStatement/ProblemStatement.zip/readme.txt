The Problem Statement is compiled using pdflatex. We have not yet met with our client so many details of the project are still unknown.

Use the make file to create the pdf file, and clean up the files.

Use "make" to create the files

Use "make clean" to clean up all the files besides the texfile.
