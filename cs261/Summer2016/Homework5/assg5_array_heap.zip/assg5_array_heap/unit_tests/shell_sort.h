#ifndef SHELL_SORT_H
#define SHELL_SORT_H

#ifndef TYPE
#define TYPE float
#endif/*ndef TYPE*/
typedef TYPE generic;

void shell_sort(generic* to_sort, int size);

#endif/*ndef SHELL_SORT_H*/
