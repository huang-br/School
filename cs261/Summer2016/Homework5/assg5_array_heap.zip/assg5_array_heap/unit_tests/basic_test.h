#ifndef BASIC_TEST_H
#define BASIC_TEST_H

#include "../p_queue.h"
#include "unit_test.h"

int main(int argc, char** argv);

#endif/*ndef BASIC_TEST_H*/
