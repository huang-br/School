#ifndef BUBBLE_SORT_H
#define BUBBLE_SORT_H

#include "vector.h"

/*TODO: You are to implement the Bubble Sort algorithm here. (See course
 * notes for algorithm details).
 * */
void bubble_sort(vector* to_sort_ptr);

#endif/*ndef BUBBLE_SORT_H*/
