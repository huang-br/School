#ifndef SHELL_SORT_H
#define SHELL_SORT_H

#include "vector.h"

/*TODO: You are to implement the Shell Sort algorithm here. (See course
 * notes for algorithm details).
 *
 * You might want to write other functions to complete this task. Any
 * additional functions you write MUST have prototypes in this file.
 * */
void shell_sort(vector* to_sort_ptr);

#endif/*ndef SHELL_SORT_H*/
