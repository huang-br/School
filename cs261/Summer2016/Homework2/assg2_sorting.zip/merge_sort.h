#ifndef MERGE_SORT_H
#define MERGE_SORT_H

#include "vector.h"

void merge_sort(vector* to_sort_ptr);

#endif/*ndef MERGE_SORT_H*/
