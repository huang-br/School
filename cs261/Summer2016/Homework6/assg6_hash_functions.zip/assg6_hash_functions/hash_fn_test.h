#ifndef HASH_FN_TEST_H
#define HASH_FN_TEST_H

#include "hash_functions.h"
#include "unit_test.h"

int main(int argc, char** argv);

#endif/*ndef HASH_FN_TEST_H*/
