#include "../tree.h"
#include "unit_test.h"

int hard_height_count(tree_node* t);

int main(int argc, char** argv);
