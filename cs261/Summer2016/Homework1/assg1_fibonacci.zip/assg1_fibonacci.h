#ifndef ASSG1_FIBONACCI
#define ASSG1_FIBONACCI

/*These are the protoypes for the functions you will write for this
 * assignment. By putting the prototypes in the header file, we make them
 * visible to the code in assg1_main.c*/
unsigned long iterative_fibonacci(int n);
unsigned long recursive_fibonacci(int n);

#endif
