#include "assg1_fibonacci.h"
/*For a given n, returns the nth fibonacci number. For full credit this
 * function must NOT make ANY function calls and compute the solution
 * iteratively. For more info see the README.*/
unsigned long iterative_fibonacci(int n) {
	/*TODO: YOUR CODE GOES HERE!*/
}

/*For a given n, returns the nth fibonacci number. For full credit this
 * function must NOT make ANY function calls except to itself and compute
 * the solution recursively. For more info see the README.*/
unsigned long recursive_fibonacci(int n) {
	/*TODO: YOUR CODE GOES HERE!*/
}
