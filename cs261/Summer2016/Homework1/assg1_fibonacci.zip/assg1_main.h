#ifndef ASSG1_MAIN
#define ASSG1_MAIN

/*These are function prototypes, hanging around in a header file as per
 * typical C coding conventions.*/
int main (int argc, char** argv);
int process_arg(char* arg);
int process_file(char* fname);
int time_fib_at_n(int n);

#endif
