/* CS261- HW1 - Program2.c*/
/* Name:
 * Date:
 * Solution description:
 */
 
#include <stdio.h>
#include <stdlib.h>

int foo(int* a, int* b, int c){
    /* Increment a */
    
    /* Decrement  b */
    
    /* Assign a-b to c */
    
    /* Return c */
}

int main(){
    /* Declare three integers x,y and z and initialize them randomly to values in [0,10] */
    
    /* Print the values of x, y and z */
    
    /* Call foo() appropriately, passing x,y,z as parameters */
    
    /* Print the values of x, y and z */
    
    /* Print the value returned by foo */
 
    /* Is the return value different than the value of z?  Why? */
    return 0;
}
    
    
