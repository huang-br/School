/* CS261- HW1 - Program6.c*/
/* Name:
 * Date:
 * Solution description:
 */
 
#include <stdio.h>
#include <stdlib.h>

/*converts ch to upper case, assuming it is in lower case currently*/
char toUpperCase(char ch){
     return ch-'a'+'A';
}

/*converts ch to lower case, assuming it is in upper case currently*/
char toLowerCase(char ch){
     return ch-'A'+'a';
}

void lowerCase(char* word){
     /* Convert to lower case letters */
}

void upperCase(char* word){
	/* Convert to upper case letters */
}

int main(){
    /* Input a word and flag */
    
    /* Print the input word and flag */
	
    /* Based on the value of flag
	  Call lowerCase()
	  or
	  Call upperCase() */
    
    /* Print the new word */
	
    
    return 0;
}
