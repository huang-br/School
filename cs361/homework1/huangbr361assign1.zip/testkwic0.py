#tests an empty string
import kwic
assert(kwic.kwic('') == ([]))
print("PASS")
