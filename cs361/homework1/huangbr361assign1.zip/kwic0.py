#testing that ir returns a string
def kwic(string, ignoreWords=[], listPairs=False, periodsToBreaks=False):
	kwiclist = ([string])
	return kwiclist

